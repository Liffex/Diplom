/*
 * Copyright (c) 2013, Pullenti. All rights reserved. Non-Commercial Freeware.
 * This class is generated using the converter UniSharping (www.unisharping.ru) from Pullenti C#.NET project (www.pullenti.ru).
 * See www.pullenti.ru/downloadpage.aspx.
 */

package com.pullenti.ner.core.internal;

public class ProgressPeace {

    public float min;

    public float max;

    public static ProgressPeace _new2880(float _arg1, float _arg2) {
        ProgressPeace res = new ProgressPeace();
        res.min = _arg1;
        res.max = _arg2;
        return res;
    }
    public ProgressPeace() {
    }
}
