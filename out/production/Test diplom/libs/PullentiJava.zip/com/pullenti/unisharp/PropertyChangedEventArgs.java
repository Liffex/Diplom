package com.pullenti.unisharp;

public class PropertyChangedEventArgs {
    public PropertyChangedEventArgs(String c) { propertyName = c; }
    public PropertyChangedEventArgs() { }
    public String propertyName;
}