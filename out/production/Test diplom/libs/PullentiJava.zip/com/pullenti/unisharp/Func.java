package com.pullenti.unisharp;

public interface Func<T, R> {

    R call(T obj);
}
