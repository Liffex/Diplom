package com.pullenti.unisharp;

public interface PropertyChangedEventHandler {

    void call(Object sender, PropertyChangedEventArgs arg);
}
